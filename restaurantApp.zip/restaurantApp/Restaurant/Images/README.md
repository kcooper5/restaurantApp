This folder is where you can place image files referenced in *menu.json*.
